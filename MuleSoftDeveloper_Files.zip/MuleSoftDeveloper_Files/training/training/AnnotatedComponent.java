package com.mulesoft.training;

import org.mule.api.MuleContext;
import org.mule.api.annotations.expressions.Lookup;
import org.mule.api.annotations.expressions.Mule;
import org.mule.api.annotations.param.InboundHeaders;
import org.mule.api.annotations.param.Payload;
import org.springframework.beans.factory.annotation.Autowired;


	public class AnnotatedComponent {
				
		//@Lookup
		@Autowired
		private PriceComponent priceComponent;
		
		//PriceComponent priceComponent = new PriceComponent();
			
		public String processMessage(@Payload String name,@Mule(value="message.id") String id,@InboundHeaders("Host") String hostName){
			
			//System.out.println("Mule Context : "+muleContext);
			System.out.println("Price Comp : "+priceComponent.getPrice("SFO"));
			System.out.println("Payload : "+name);
			System.out.println("Message Id : "+id );
			System.out.println("Host Name : "+hostName);
			return "Hello "+name;
		}
		
		public String processMessage(@Payload String name,@Mule(value="message.id") String id){
			
			//System.out.println("Mule Context : "+muleContext);
			System.out.println("Price Comp : "+priceComponent.getPrice("SFO"));
			System.out.println("Payload : "+name);
			System.out.println("Message Id : "+id );
			return "Hello "+name;
		}
	}

package com.mulesoft.training;

public class PriceConstractor {
	
	public PriceConstractor(){
		System.out.println("PriceConstractor().PriceConstractor <---- CONSTRACTOR ");
	}
	
	public String getPrice(){
		System.out.println("PriceConstractor().getPrice <--- CALLED ");
		
		return "PriceConstractor().getPrice <--- CALLED ";
	}

}

package com.mulesoft.training;

public class PriceComponentWithTwoMethods  {	
	
	public String getRate(String destination) {	
		System.out.println("PriceComponent.getRate()");
		
		if (destination != null && "SFO".equalsIgnoreCase(destination.trim())) {
			return "300";			
		} else if (destination != null && "/SFO".equalsIgnoreCase(destination.trim())) {
			return "300";			
		} else if (destination != null && "BOS".equalsIgnoreCase(destination.trim())) {
			return "400";
		} else if (destination != null && "LAX".equalsIgnoreCase(destination.trim())) {
			return "500";
		} else {
			return "This destination is not available";
		}
		
	}

	public String getPrice(String destination) {		
		System.out.println("PriceComponent.getPrice()");		
		return getRate(destination);		
	}
	
	public String aMethod(Integer aNumber) throws Exception {
		return "The Ultimate Answer!";
	}

}

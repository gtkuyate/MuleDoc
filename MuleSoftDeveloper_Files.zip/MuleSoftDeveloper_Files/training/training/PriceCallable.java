package com.mulesoft.training;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class PriceCallable implements Callable{

	
	public PriceCallable(){
		System.out.println("PriceCallable().PriceConstractor <---- CONSTRACTOR Called...");
	}
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		// TODO Auto-generated method stub
		MuleMessage mMsg = eventContext.getMessage();
		Object payload = mMsg.getPayload();
		
		return null;
	}

}

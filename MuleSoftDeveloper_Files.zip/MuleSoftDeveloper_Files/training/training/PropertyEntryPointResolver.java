package com.mulesoft.training;

public class PropertyEntryPointResolver {
	
	public String getRate() {	
		System.out.println("PriceComponent.getRate()");
		
		return "This destination is not available";
		
	}

	public String getPrice() {		
		System.out.println("PriceComponent.getPrice()");		
		return getRate();		
	}
}

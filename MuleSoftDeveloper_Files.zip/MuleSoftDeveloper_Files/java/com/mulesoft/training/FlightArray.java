package com.mulesoft.training;

import java.util.List;

public class FlightArray {
		
	private List<Flight> flights;

	public List<Flight> getFlights() {
		return flights;
	}

	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}
		
}
